// stack_challenges.dart

// Challenge 1: Reverse a List
void reverseList(List list) {
  for (int i = list.length - 1; i >= 0; i--) {
    print(list[i]);
  }
}

// Challenge 2: Balance the Parentheses
bool isBalanced(String s) {
  List<String> stack = [];
  for (var char in s.split('')) {
    if (char == '(') {
      stack.add(char);
    } else if (char == ')') {
      if (stack.isEmpty) return false;
      stack.removeLast();
    }
  }
  return stack.isEmpty;
}
