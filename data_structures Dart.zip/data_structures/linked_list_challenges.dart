// linked_list_challenges.dart

class Node {
  int data;
  Node? next;

  Node(this.data);
}

// Challenge 1: Print Linked List in Reverse
void printReverse(Node? head) {
  if (head == null) return;
  printReverse(head.next);
  print(head.data);
}

// Challenge 2: Find Middle Node
Node? findMiddle(Node? head) {
  Node? slow = head;
  Node? fast = head;

  while (fast != null && fast.next != null) {
    slow = slow!.next;
    fast = fast.next!.next;
  }
  return slow;
}

// Challenge 3: Reverse Linked List
Node? reverseList(Node? head) {
  Node? prev;
  Node? current = head;
  Node? next;

  while (current != null) {
    next = current.next;
    current.next = prev;
    prev = current;
    current = next;
  }
  return prev;
}

// Challenge 4: Remove All Occurrences of a value
Node? removeAll(Node? head, int value) {
  // Remove from beginning if matches
  while (head != null && head.data == value) {
    head = head.next;
  }

  Node? current = head;
  while (current != null && current.next != null) {
    if (current.next!.data == value) {
      current.next = current.next!.next;
    } else {
      current = current.next;
    }
  }
  return head;
}
